from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import os
import jwt
import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///news.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class News(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.String(1000), nullable=False)

# JWT Token Required Decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.args.get('token')
        if not token:
            return jsonify({'message': 'Token is missing!'}), 403
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
        except:
            return jsonify({'message': 'Token is invalid!'}), 403
        return f(*args, **kwargs)
    return decorated

@app.route('/login', methods=['POST'])
def login():
    auth = request.authorization
    if not auth or not auth.username or not auth.password:
        return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

    user = User.query.filter_by(username=auth.username).first()
    if not user:
        return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

    if user.check_password(auth.password):
        token = jwt.encode({
            'user': user.username,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
        }, app.config['SECRET_KEY'])

        return jsonify({'token': token})

    return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

@app.route('/news', methods=['GET'])
@token_required
def get_news():
    news_articles = News.query.all()
    output = []
    for news in news_articles:
        news_data = {'id': news.id, 'title': news.title, 'content': news.content}
        output.append(news_data)

    return jsonify({'news': output})

@app.route('/news', methods=['POST'])
@token_required
def add_news():
    data = request.get_json()
    new_news = News(title=data['title'], content=data['content'])
    db.session.add(new_news)
    db.session.commit()

    return jsonify({'message': 'News item created!'})

@app.route('/news/<id>', methods=['PUT'])
@token_required
def update_news(id):
    news = News.query.get_or_404(id)
    data = request.get_json()
    news.title = data['title']
    news.content = data['content']
    db.session.commit()

    return jsonify({'message': 'News item has been updated!'})

@app.route('/news/<id>', methods=['DELETE'])
@token_required
def delete_news(id):
    news = News.query.get_or_404(id)
    db.session.delete(news)
    db.session.commit()

    return jsonify({'message': 'News item deleted!'})

if __name__ == '__main__':
    app.run(debug=True)
