#include <iostream>
#include <fstream>
#include <sqlite3.h>

using namespace std;


void deleteDuplicateEmails(sqlite3 *db);

int main() {
    sqlite3 *db;
    char *zErrMsg = 0;
    int rc;
    char *sql;

    // Open database connection
    rc = sqlite3_open("test.db", &db);
    if(rc) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        return 0;
    } else {
        std::cout << "Opened database successfully" << std::endl;
    }

    // Create table in database for Emails
    sql = "CREATE TABLE IF NOT EXISTS Emails(id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE)";
    rc = sqlite3_exec(db, sql, 0, 0, &zErrMsg);
    if(rc != SQLITE_OK) {
        std::cerr << "Error creating table: " << zErrMsg << std::endl;
        sqlite3_free(zErrMsg);
    } else {
        std::cout << "Table created successfully" << std::endl;
    }

    // Read file and insert Emails data with emails and IDs
    std::ifstream file("emails.txt");
    std::string line;
    const char* insertEmailsSQL = "INSERT INTO Emails(email) VALUES(?)";
    sqlite3_stmt* stmt;
    rc = sqlite3_prepare_v2(db, insertEmailsSQL, -1, &stmt, nullptr);

    if(rc != SQLITE_OK) {
        std::cerr << "Error preparing insert statement." << std::endl;
        return 1;
    }

    while(std::getline(file, line)) {
        sqlite3_bind_text(stmt, 1, line.c_str(), -1, SQLITE_STATIC);
        rc = sqlite3_step(stmt);
        if(rc != SQLITE_DONE) {
            std::cerr << "Error executing insert statement." << std::endl;
            return 1;
        }
        sqlite3_reset(stmt);
    }
    file.close();
    sqlite3_finalize(stmt);

    // Call delete duplicate Emails
    deleteDuplicateEmails(db);

    // Close the database connection
    sqlite3_close(db);
    return 0;
}

void deleteDuplicateEmails(sqlite3 *db) {
    char *zErrMsg = 0;
    const char *sql = "DELETE FROM Emails WHERE Id NOT IN (SELECT MIN(Id) FROM Emails GROUP BY Email);";
    int rc = sqlite3_exec(db, sql, 0, 0, &zErrMsg);
    if(rc != SQLITE_OK) {
        std::cerr << "SQL error: " << zErrMsg << std::endl;
        sqlite3_free(zErrMsg);
    } else {
        std::cout << "Duplicate emails deleted successfully" << std::endl;
    }
}
