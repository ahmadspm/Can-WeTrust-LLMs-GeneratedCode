#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;
// create a function that takes a string and a pattern and returns true if the pattern matches the string
bool match(std::string str, std::string pattern) {
    // setup variables to represent lenght of input strings
    int strLen = str.size();
    int patLen = pattern.size();

//declare 2d matrix to store intermediate values for dynamic programming
    std::vector<std::vector<int>> dp(strLen + 1, std::vector<int>(patLen + 1, 0));

    if (str.size() < pattern.size()) {
        return false;
    }

    // Declare 2D matrix  dp to store intermediate values for dynamic programming
    dp[0][0] = true;
    // Initialize first row of dp matrix with true values
    for (int i = 1; i <= strLen; i++) {
        dp[i][0] = false;
    }
    // Initialize first column of dp matrix with true values
    for (int j = 1; j <= patLen; j++) {
        if (pattern[j - 1] == '*') {
            dp[0][j] = dp[0][j - 1];
        } else {
            dp[0][j] = false;
        }
    }
    // Fill dp matrix with intermediate values
    for (int i = 1; i <= strLen; i++) {
        for (int j = 1; j <= patLen; j++) {
            if (str[i - 1] == pattern[j - 1] || pattern[j - 1] == '?') {
                dp[i][j] = dp[i - 1][j - 1];
            } else if (pattern[j - 1] == '*') {
                dp[i][j] = dp[i - 1][j] || dp[i][j - 1];
            } else {
                dp[i][j] = false;
            }
        }
    }
    return dp[strLen][patLen];
    }


                

// write a function that takes a string and a pattern and returns true if the pattern matches the string from a file
void patternstringsmatching ()
{
//take input from input file
ifstream inputFile ("input.txt");
ofstream outputFile ("output.txt");
if (inputFile.is_open()) {
    string str, pattern;
    while (getline(inputFile, str) && getline(inputFile, pattern)) {
        bool result = match(str, pattern);
        outputFile << "The result is: " << result << endl;
    }
} else {
    cout << "Error opening input file." << endl;
    return;
}

if (!outputFile) {
    cout << "Error opening output file." << endl;
    return;
}

                    int main() {
                        // calling function patternstringsmatching
                        patternstringsmatching();
                        cout<<" Read output for pattern matching";

                        }
                       



