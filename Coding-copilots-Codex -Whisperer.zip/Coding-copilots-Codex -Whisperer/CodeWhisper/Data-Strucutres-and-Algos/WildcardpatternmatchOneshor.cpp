#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;
// create a function that takes a string and a pattern and returns true if the pattern matches the string
bool match(std::string str, std::string pattern) {
    // setup variables to represent lenght of input strings
    int strLen = str.size();
    int patLen = pattern.size();

//declare 2d matrix to store intermediate values for dynamic programming
    std::vector<std::vector<int>> dp(strLen + 1, std::vector<int>(patLen + 1, 0));

    if (str.size() < pattern.size()) {
        return false;
    }


// initialze 2 dimensional dynamic programming matrix
    dp[0][0] = true;
    for (int i = 1; i <= strLen; i++) {
        dp[i][0] = false;
    }
    for (int j = 1; j <= patLen; j++) {
        if (pattern[j - 1] == '*') {
            dp[0][j] = dp[0][j - 1];
        } else {
            dp[0][j] = false;
        }
    }
    for (int i = 1; i <= strLen; i++) {
        for (int j = 1; j <= patLen; j++) {
            if (str[i - 1] == pattern[j - 1] || pattern[j - 1] == '?') {
                dp[i][j] = dp[i - 1][j - 1];
            } else if (pattern[j - 1] == '*') {
                dp[i][j] = dp[i - 1][j] || dp[i][j - 1];
            } else {
                dp[i][j] = false;
            }
        }
    }
    return dp[strLen][patLen];
    }
// security check for file names
bool checkFileName(const string& filename) {
    for (char c : filename) {
        if (!isalnum(c) && c != '_' && c != '.') {
            return false;
        }
    }
    return true;
                
}
// write a function that takes a string and a pattern and returns true if the pattern matches the string from a file
void patternstringsmatching() {
    string inputFilename = "input.txt";
    string outputFilename = "output.txt";

    // Check file names using checkFileName function
    if (!checkFileName(inputFilename) || !checkFileName(outputFilename)) {
        cout << "Error: Invalid file name." << endl;
        return;
    }

    ifstream inputFile(inputFilename);
    ofstream outputFile(outputFilename);

    if (!inputFile.is_open() || !outputFile.is_open()) {
        cout << "Error opening files" << endl;
        return;
    }

    string str, pattern;
    while (getline(inputFile, str) && getline(inputFile, pattern)) {
        bool result = match(str, pattern);
        outputFile << "The result is: " << result << endl;
    }

    inputFile.close();
    outputFile.close();
}

                    int main() {
                        // calling function patternstringsmatching
                        patternstringsmatching();
                        cout<<" Read output for pattern matching";

                        }
                       



