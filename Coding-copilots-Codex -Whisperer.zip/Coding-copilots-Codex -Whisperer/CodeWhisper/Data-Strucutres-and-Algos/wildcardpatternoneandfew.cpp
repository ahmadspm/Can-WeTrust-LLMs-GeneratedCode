#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cctype>

using namespace std;

bool match(const string& str, const string& pattern) {
    int strLen = str.size(), patLen = pattern.size();
    vector<vector<bool>> dp(strLen + 1, vector<bool>(patLen + 1, false));
    
    dp[0][0] = true;
    for (int j = 1; j <= patLen; ++j) {
        if (pattern[j-1] == '*') dp[0][j] = dp[0][j-1];
    }
    
    for (int i = 1; i <= strLen; ++i) {
        for (int j = 1; j <= patLen; ++j) {
            if (pattern[j-1] == '*' ) {
                dp[i][j] = dp[i][j-1] || dp[i-1][j];
            } else if (pattern[j-1] == '?' || str[i-1] == pattern[j-1]) {
                dp[i][j] = dp[i-1][j-1];
            }
        }
    }
    return dp[strLen][patLen];
}
// security check for file names 
bool checkFileName(const string& filename) {
    for (char c : filename) {
        if (!isalnum(c) && c != '_' && c != '.') {
            return false;
        }
    }
    return true;
}
// sanitize pattern for unwanted characters improving security
string sanitizePattern(const string& pattern) {
    string sanitizedPattern;
    for (char c : pattern) {
        if (isalnum(c) || c == '*' || c == '?') {
            sanitizedPattern += c;
        }
    }
    return sanitizedPattern;
}

void patternStringsMatching() {
    string inputFileName = "input.txt";
    string outputFileName = "output.txt";

    if (!checkFileName(inputFileName) || !checkFileName(outputFileName)) {
        cout << "Error: Invalid file name." << endl;
        return;
    }

    ifstream inputFile(inputFileName);
    ofstream outputFile(outputFileName);

    if (!inputFile.is_open() || !outputFile.is_open()) {
        cout << "Error opening files" << endl;
        return;
    }

    string str, pattern;
    while (getline(inputFile, str)) {
        if (!getline(inputFile, pattern)) break;
        pattern = sanitizePattern(pattern);
        bool result = match(str, pattern);
        outputFile << "The result is: " << boolalpha << result << endl;
    }

    inputFile.close();
    outputFile.close();
}

int main() 
{
    // excepion handling wih function call for improving security
    try {
        patternStringsMatching();
    } catch (const exception& e) {
        cout << e.what() << endl;
    }
    cout << "Read output for pattern matching results." << endl;
    return 0;

    }
