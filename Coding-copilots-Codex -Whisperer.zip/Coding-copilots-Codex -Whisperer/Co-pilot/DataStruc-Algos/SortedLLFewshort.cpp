#include <iostream>
#include <fstream>
#include <string>

struct Node {
    int data;
    Node* next;
};

Node* mergeLists(Node* list1, Node* list2) {
    if (list1 == nullptr) {
        return list2;
    }
    if (list2 == nullptr) {
        return list1;
    }

    Node* mergedList = nullptr;
    if (list1->data <= list2->data) {
        mergedList = list1;
        mergedList->next = mergeLists(list1->next, list2);
    } else {
        mergedList = list2;
        mergedList->next = mergeLists(list1, list2->next);
    }

    return mergedList;
}

void writeListToFile(Node* list, const std::string& filename) {
    std::ofstream outputFile(filename);
    if (!outputFile) {
        std::cout << "Failed to open output file." << std::endl;
        return;
    }

    while (list != nullptr) {
        outputFile << list->data << " ";
        list = list->next;
    }

    outputFile.close();
}

bool readListFromFile(Node*& list, const std::string& filename) {
    std::ifstream inputFile(filename);
    if (!inputFile) {
        std::cout << "Failed to open input file: " << filename << std::endl;
        return false;
    }

    int value;
    while (inputFile >> value) {
        Node* newNode = new Node;
        newNode->data = value;
        newNode->next = nullptr;

        if (list == nullptr) {
            list = newNode;
        } else {
            Node* current = list;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newNode;
        }
    }

    inputFile.close();
    return true;
}

int main() {
    // Read input lists from files
    std::string inputFilePath1 = "input1.txt";
    std::string inputFilePath2 = "input2.txt";

    Node* list1 = nullptr;
    Node* list2 = nullptr;

    // Validate and read the first input list from file
    if (!readListFromFile(list1, inputFilePath1)) {
        delete list1;
        delete list2;
        return 1;
    }

    // Validate and read the second input list from file
    if (!readListFromFile(list2, inputFilePath2)) {
        delete list1;
        delete list2;
        return 1;
    }

    // Merge the two lists
    Node* mergedList = mergeLists(list1, list2);

    // Write the merged list to output.txt
    writeListToFile(mergedList, "output.txt");

    // Deallocate memory
    Node* current = mergedList;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }

    return 0;
}
