#include <iostream>
#include <fstream>

struct Node {
    int data;
    Node* next;
};

Node* mergeLists(Node* list1, Node* list2) {
    if (list1 == nullptr) {
        return list2;
    }
    if (list2 == nullptr) {
        return list1;
    }

    Node* mergedList = nullptr;
    if (list1->data <= list2->data) {
        mergedList = list1;
        mergedList->next = mergeLists(list1->next, list2);
    } else {
        mergedList = list2;
        mergedList->next = mergeLists(list1, list2->next);
    }

    return mergedList;
}

void writeListToFile(Node* list, const std::string& filename) {
    std::ofstream outputFile(filename);
    if (!outputFile) {
        std::cout << "Failed to open output file." << std::endl;
        return;
    }

    while (list != nullptr) {
        outputFile << list->data << " ";
        list = list->next;
    }

    outputFile.close();
}

int main() {
    // Read input lists from files
    std::ifstream inputFile1("input1.txt");
    std::ifstream inputFile2("input2.txt");

    if (!inputFile1 || !inputFile2) {
        std::cout << "Failed to open input files." << std::endl;
        return 1;
    }

    Node* list1 = nullptr;
    Node* list2 = nullptr;

    // Populate list1 from input1.txt
    // ...

    // Populate list2 from input2.txt
    // ...

    inputFile1.close();
    inputFile2.close();

    // Merge the two lists
    Node* mergedList = mergeLists(list1, list2);

    // Write the merged list to output.txt
    writeListToFile(mergedList, "output.txt");

    return 0;
}
