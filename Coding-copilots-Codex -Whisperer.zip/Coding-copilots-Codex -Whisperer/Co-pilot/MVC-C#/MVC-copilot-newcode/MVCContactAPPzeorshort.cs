using System;
using System.Collections.Generic;

namespace MVCContactApp
{
    // Model
    public class Contact
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }

    // View
    public class ContactView
    {
        public void DisplayContact(Contact contact)
        {
            Console.WriteLine($"Contact ID: {contact.Id}");
            Console.WriteLine($"Name: {contact.Name}");
            Console.WriteLine($"Email: {contact.Email}");
            Console.WriteLine($"Phone: {contact.Phone}");
        }

        public Contact GetContactDetails()
        {
            Console.Write("Enter Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter Email: ");
            string email = Console.ReadLine();

            Console.Write("Enter Phone: ");
            string phone = Console.ReadLine();

            return new Contact { Name = name, Email = email, Phone = phone };
        }
    }

    // Web View
    public class WebContactView
    {
        public void DisplayContact(Contact contact)
        {
            Console.WriteLine("<h1>Contact Details</h1>");
            Console.WriteLine($"<p>Contact ID: {contact.Id}</p>");
            Console.WriteLine($"<p>Name: {contact.Name}</p>");
            Console.WriteLine($"<p>Email: {contact.Email}</p>");
            Console.WriteLine($"<p>Phone: {contact.Phone}</p>");
        }

        public Contact GetContactDetails()
        {
            Console.WriteLine("<h1>Add New Contact</h1>");
            Console.WriteLine("<form>");
            Console.WriteLine("<label for='name'>Name:</label>");
            Console.WriteLine("<input type='text' id='name' name='name'><br>");
            Console.WriteLine("<label for='email'>Email:</label>");
            Console.WriteLine("<input type='text' id='email' name='email'><br>");
            Console.WriteLine("<label for='phone'>Phone:</label>");
            Console.WriteLine("<input type='text' id='phone' name='phone'><br>");
            Console.WriteLine("<input type='submit' value='Add Contact'>");
            Console.WriteLine("</form>");

            string name = Console.ReadLine();
            string email = Console.ReadLine();
            string phone = Console.ReadLine();

            return new Contact { Name = name, Email = email, Phone = phone };
        }
    }

    // Controller
    public class ContactController
    {
        private List<Contact> contacts;
        private ContactView view;

        public ContactController()
        {
            contacts = new List<Contact>();
            view = new ContactView();
        }

        public void AddContact()
        {
            Contact contact = view.GetContactDetails();
            contact.Id = contacts.Count + 1;
            contacts.Add(contact);
            Console.WriteLine("Contact added successfully!");
        }

        public void ViewContact(int id)
        {
            Contact contact = contacts.Find(c => c.Id == id);
            if (contact != null)
            {
                view.DisplayContact(contact);
            }
            else
            {
                Console.WriteLine("Contact not found!");
            }
        }

        public void UpdateContact(int id)
        {
            Contact contact = contacts.Find(c => c.Id == id);
            if (contact != null)
            {
                Console.WriteLine("Enter new contact details:");
                Contact updatedContact = view.GetContactDetails();
                updatedContact.Id = contact.Id;
                contacts[contacts.IndexOf(contact)] = updatedContact;
                Console.WriteLine("Contact updated successfully!");
            }
            else
            {
                Console.WriteLine("Contact not found!");
            }
        }

        public void DeleteContact(int id)
        {
            Contact contact = contacts.Find(c => c.Id == id);
            if (contact != null)
            {
                contacts.Remove(contact);
                Console.WriteLine("Contact deleted successfully!");
            }
            else
            {
                Console.WriteLine("Contact not found!");
            }
        }
    }

    // Main Program
    class Program
    {
        static void Main(string[] args)
        {
            ContactController controller = new ContactController();

            while (true)
            {
                Console.WriteLine("1. Add Contact");
                Console.WriteLine("2. View Contact");
                Console.WriteLine("3. Update Contact");
                Console.WriteLine("4. Delete Contact");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        controller.AddContact();
                        break;
                    case 2:
                        Console.Write("Enter Contact ID: ");
                        int viewId = Convert.ToInt32(Console.ReadLine());
                        controller.ViewContact(viewId);
                        break;
                    case 3:
                        Console.Write("Enter Contact ID: ");
                        int updateId = Convert.ToInt32(Console.ReadLine());
                        controller.UpdateContact(updateId);
                        break;
                    case 4:
                        Console.Write("Enter Contact ID: ");
                        int deleteId = Convert.ToInt32(Console.ReadLine());
                        controller.DeleteContact(deleteId);
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }

                Console.WriteLine();
            }
        }
    }
}