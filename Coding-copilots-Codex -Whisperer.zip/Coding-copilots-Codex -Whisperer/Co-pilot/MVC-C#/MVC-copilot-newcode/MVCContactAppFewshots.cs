using System.Web.Script.Serialization;

// ...

public class WebContactView
{
    private JavaScriptSerializer serializer;

    public WebContactView()
    {
        serializer = new JavaScriptSerializer();
    }

    // ...

    public string GetSerializedContactDetails()
    {
        Contact contact = GetContactDetails();
        return serializer.Serialize(contact);
    }
}