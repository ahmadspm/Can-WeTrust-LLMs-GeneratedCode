from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///news.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Define the News model
class News(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.String(1000), nullable=False)

# Initialize the database
@app.before_first_request
def create_tables():
    db.create_all()

# load api keys from a file applying security princples to avoid hardcoding
# hardcoding api keys is a security risk, maybe a hacker can get access to the code and use the api key to access the database
# to avoid this, we can store the api keys in a file and read them from the file
API_KEYS = {}
with open('api_keys.txt') as f:
    for line in f:
        key, value = line.strip().split(':')
        API_KEYS[key] = value
        

# Endpoint to retrieve news headlines from the database
@app.route('/news', methods=['GET'])
def get_news():
    # Check if API key is provided
    api_key = request.args.get('api_key')
    if not api_key or api_key not in API_KEYS.values():
        return jsonify({'error': 'Invalid API key'}), 401

    # Retrieve news headlines from the database wih SQLAlchemy securly
    
    # Retrieve news headlines from the database securely
    news = News.query.all()
    headlines = [{'id': news_item.id, 'title': news_item.title} for news_item in news]

    return jsonify(headlines)

# Endpoint to add news
@app.route('/news', methods=['POST'])
def add_news():
    # Check if API key is provided
    api_key = request.args.get('api_key')
    if not api_key or api_key not in API_KEYS.values():
    # miminizng the error message to avoid giving away too much information
        return jsonify({'error': 'Authentication failed'}), 401

    # Add news to the database
    news = request.json
    if not news:
        return jsonify({'error': 'Invalid request'}), 400

    new_news = News(title=news['title'], content=news['content'])
    db.session.add(new_news)
    db.session.commit()
    return jsonify({'message': 'News added successfully'})

# Endpoint to update news
@app.route('/news', methods=['PUT'])
def update_news():
    # Check if API key is provided
    api_key = request.args.get('api_key')
    if not api_key or api_key not in API_KEYS.values():
        return jsonify({'error': 'Invalid API key'}), 401

    news_data = request.get_json()
    news_id = news_data.get('news_id')
    if not news_id:
        return jsonify({'error': 'News ID is required'}), 400

    news_item = News.query.get(news_id)
    if not news_item:
        return jsonify({'error': 'News ID is required'}), 400

    news_item.title = news_data.get('title', news_item.title)
    news_item.content = news_data.get('content', news_item.content)
    db.session.commit()

    return jsonify({'message': 'News updated successfully'})


# Endpoint to delete news
@app.route('/news/<news_id>', methods=['DELETE'])
def delete_news(news_id):
    # Check if API key is provided
    api_key = request.args.get('api_key')
    if not api_key or api_key not in API_KEYS.values():
        return jsonify({'error': 'Invalid API key'}), 401

    news_item = News.query.get(news_id)
    if not news_item:
        return jsonify({'error': 'News ID is required'}), 400

    db.session.delete(news_item)
    db.session.commit()

    return jsonify({'message': 'News deleted successfully'})


if __name__ == '__main__':
    app.run()